import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Carousel from 'react-native-snap-carousel';


const HomeScreen = () => {
    

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.userName}>Bem Vindo</Text>
          <View style={styles.logoContainer}>
            <Text style={styles.logo}>LOGO</Text>
          </View>
        </View>
        <View style={styles.carouselContainer}>
          <Carousel
            data={[{ id: '1' }, { id: '2' }, { id: '3' }]}
            renderItem={({ item }) => (
              <View style={styles.carouselItem} key={item.id} />
            )}
            sliderWidth={400}
            itemWidth={360}
            loop
            autoplay
            autoplayInterval={5000}
            inactiveSlideScale={0.8}
            inactiveSlideOpacity={0.7}
            layout={'default'}
          />
        </View>
        <View style={styles.footer}>
          <View style={styles.buttonContainer}>
            <View style={styles.button}>
                <Text style={styles.buttonText}>Button 1</Text>
            </View>
            <View style={styles.button}>
                <Text style={styles.buttonText}>Button 2</Text>
                <Text style={styles.buttonText}>Button 2</Text>
            </View>
            <View style={styles.button}>
                <Text style={styles.buttonText}>Button 3</Text>
            </View>
            <View style={styles.button}>
                <Text style={styles.buttonText}>Button 4</Text>
            </View>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor:'#FAF0E6',
  },
  container: {
    flex: 1,

  },
  header: {
    height: 100,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    borderBottomColor: '#ddd',
  },
  userName: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  logoContainer: {
    backgroundColor: '#ddd',
    width: 50,
    height: 50,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    fontWeight: 'bold',
    fontSize: 20,
    color: '#333',
  },
  carouselContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop:20,
    marginBottom:10,

  },
  carouselItem: {
    width: '100%',
    height: '100%',
    borderRadius: 40,
    backgroundColor: '#ddd',
  },
  footer:{
    
    width:'100%',
    height: 180,
    justifyContent: 'space-around',
    alignItems: 'center',

  },

  buttonContainer: {
    width: '95%',
    height: '80%',
    borderRadius:40,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor:'white',
    padding:7,    
  },
  button: {
    flexDirection:'column',
    width:70,
    height:70,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor:'#F8F8FF',
    borderRadius:15,
    padding:3,

  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default HomeScreen;
