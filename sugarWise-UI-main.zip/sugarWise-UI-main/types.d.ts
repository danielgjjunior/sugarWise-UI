declare module 'react-native-animatable' {
    export interface AnimatableProperties {
      flash?: 'slow' | 'fast' | number;
    }
  }
  